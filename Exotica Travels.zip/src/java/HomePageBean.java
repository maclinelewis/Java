/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exoticatravels;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author lovely
 */
public class HomePageBean extends org.apache.struts.action.ActionForm {
    
    private String r1;
    
    private String r2;

    /**
     * @return
     */
    public HomePageBean() {
        super();
    }
    public String getR1(){
        return r1;
    }

    /**
     * @param string
     */
    public void setR1(String r1) {
        this.r1 = r1;
    }

    /**
     * @return
     */
}