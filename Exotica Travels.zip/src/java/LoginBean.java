/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exoticatravels;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author lovely
 */
public class LoginBean extends org.apache.struts.action.ActionForm {
    
    private String userid,password,r1;
    
   public LoginBean(){
       super();
   }

    /**
     * @return
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param string
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * @return
     */
    public String getR1() {
        return r1;
    }

    /**
     * @param i
     */
    public void setR1(String r1) {
        this.r1 = r1;
    }

    /**
     *
     */
   public String getUserid(){
       return userid;
   }
   public void setUserid(String userid){
       this.userid = userid;
   }
   }