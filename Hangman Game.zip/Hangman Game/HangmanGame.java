package game;
import java.util.Scanner;
import java.util.Random;
public class HangmanGame {
//Instance variable
String word[] ={"japan","qatar","syria","mongalia","bahrain","india"};
public void playGame(){               
    int len,i,count=0,rnd,flag=0;
    String choice,temp;
    Random rd = new Random();
    Scanner input = new Scanner(System.in);
    rnd=rd.nextInt(6);/*Generates a random number b/w -1 to 7 and assigns the same to variable rnd*/
    len = word[rnd].length();
    char[] newString = new char[len];
    StringBuffer wrgstring = new StringBuffer();
    for(int j=0;j<len;j++){
        System.out.print("_ ");
    }
    System.out.println("");
    do{
        flag=0;
        System.out.println("\n\nEnter your Guess:" );
        //implement user defined exception
        try
        {
            String ch = input.nextLine().toLowerCase();
            if(ch.length()!=1){
                throw new WrongInputException();
        }
        
        count++;
        for(i=0;i<len;i++){
            if(word[rnd].charAt(i)==ch.charAt(0)){
                newString[i]=word[rnd].charAt(i);
                flag=1;
            }
        }
        if(flag == 0){
            flag=1;
            wrgstring.append(ch).append(",");
            System.out.println("\nMisses:"+wrgstring);
        }
        System.out.println(newString);
        temp=new String(newString);
        if(word[rnd].equals(temp)){
            System.out.println("-----Congrats :) You won------");
            System.out.println("Do you want to play again(Y/N)");
            choice = input.nextLine();
            if(choice.equalsIgnoreCase("y")){
                playGame();
                
            }
            else{
                showMenu();
            }
        }
        }
        catch (WrongInputException e){
            //System.out.println(e);
            flag=1;
        }
    }while(flag!=0);
    }
public void instructGame(){
    System.out.println("InstructGame Method is invoked");
}
public void exitGame(){
    System.out.println("Exit game Method is invoked");
}

public void showMenu(){
    int option;
    Scanner sc = new Scanner(System.in);
    System.out.println("-----Menu------");
    System.out.println("1.Play");
    System.out.println("2.Instructions");
    System.out.println("3.Exit");
    System.out.println("\nChoose the option");
    //try-catch block
    option=0;
    try{
    option = sc.nextInt();
    }
    catch(RuntimeException e){
        System.out.println("Please provide a valid numeric input");
        showMenu();
    }
    switch(option){
        case 1: playGame();
                break;
        case 2: instructGame();
                break;
        case 3: exitGame();
                break;
        default: 
            try{
                throw new MenuInputException();
                
            }
            catch(Exception e){
            showMenu();
        }
 }
//Method Definition

     }
    
    public static void main(String[] args) {
       Menu gobj = new Menu();
       gobj.addComponent();
       
    }
    
}
